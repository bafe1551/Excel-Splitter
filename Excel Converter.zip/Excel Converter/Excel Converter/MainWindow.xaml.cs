﻿using System;
using Microsoft.Win32;
using System.Data.OleDb;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using Path = System.IO.Path;

namespace Excel_Converter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string provider;
        private OleDbConnection conn;

        private bool PrepareExcelConnection()
        {

            // NOTE: it will be created if not exists
            var prvdr = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=" + FilePath + ";Extended Properties=Excel 16.0 Xml";

            try
            {
                conn = new OleDbConnection(prvdr);
                conn.Open();
            }
            catch (Exception e1)
            {
                prvdr = "Provider=Microsoft.ACE.OLEDB.15.0;Data Source=" + FilePath + ";Extended Properties=Excel 15.0 Xml";

                try
                {
                    conn = new OleDbConnection(prvdr);
                    conn.Open();
                }
                catch (Exception e2)
                {
                    prvdr = "Provider=Microsoft.ACE.OLEDB.14.0;Data Source=" + FilePath + ";Extended Properties=Excel 14.0 Xml";
                    try
                    {
                        conn = new OleDbConnection(prvdr);
                        conn.Open();
                    }
                    catch (Exception e3)
                    {
                        prvdr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=Excel 12.0 Xml";
                        try
                        {
                            conn = new OleDbConnection(prvdr);
                            conn.Open();
                        }
                        catch (Exception e4)
                        {
                            return false;
                        }
                    }
                }
            }
            provider = prvdr;
            return true;
        }
        public string FilePath = "";

        public string FullFolderPath = "";
        public DataSet DataSet { get; private set; }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {

            btnBrowse.IsEnabled = false;
            OpenFileDialog fd = new OpenFileDialog();

            fd.Title = "Select your ExceL File:";
            fd.Filter = "Excel Worksheets (.xls, .xlsx, .lsm, .csv)| *.xls; *.xlsm; *.xlsx; *.csv;";
            fd.DefaultExt = ".xls";


            Nullable<bool> result = fd.ShowDialog();

            if (result == true)
            {
                FilePath = fd.FileName;
            }
            btnBrowse.IsEnabled = true;


        }


        private void btnBrowseDestination_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog fd = new System.Windows.Forms.FolderBrowserDialog();

            // Sets starting directory of browse to 3 levels up from current directory
            fd.SelectedPath = System.IO.Path.GetFullPath(System.IO.Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\"));

            System.Windows.Forms.DialogResult result = fd.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                FullFolderPath = fd.SelectedPath;
            }
        }

        private void Run(object sender, RoutedEventArgs e)
        {
            DataSet = new DataSet();
            ReadFile();
            WriteFiles();
        }
        public void ReadFile()
        {
            if (FilePath != "")
            {

                //Act on the file as a csv

                String excelStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + @"; Extended Properties=""Excel 12.0; HDR=Yes; IMEX=2;"""; // File path and settings

                OleDbConnection connection = new OleDbConnection(excelStr);

                OleDbCommand DBCommand = new OleDbCommand();
                OleDbDataAdapter DBAdapter = new OleDbDataAdapter(DBCommand);

                DataTable dataTable;
                List<String> listSheet = new List<String>();
                DataRow dataRow;
                String sql;
                //try
                //{
                //    if (Path.GetExtension(FilePath) == ".csv")
                //    {
                //        StreamReader sr = new StreamReader(FilePath);
                //        char[] delimChar = { ',', '\t' };
                //        string[] headers = sr.ReadLine().Split(delimChar);
                //        DataTable dt = new DataTable();
                //        foreach (string header in headers)
                //        {
                //            dt.Columns.Add(header);
                //        }
                //        if(headers.Contains("Student ID")||headers.Contains("Document Name"))
                //        {

                //        }
                //        else
                //        {

                //        }
                //    }
                //}
                //catch
                //{

                //}
                try
                {
                    DBCommand.Connection = connection;
                    DBCommand.CommandType = CommandType.Text;

                    connection.Open();

                    dataTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    // Creates a list of the tables names from the DataRow
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        dataRow = dataTable.Rows[i];
                        listSheet.Add(dataRow["TABLE_NAME"].ToString());
                        Console.WriteLine(dataRow["TABLE_NAME"].ToString());
                    }

                    // Fills up the DataSet from the created list
                    for (int i = 0; i < listSheet.Count; i++)
                    {
                        string sheet = listSheet[i];

                        if (!sheet.Contains("FilterDatabase")) // Checks to make sure that the sheet isn't a hidden repeat sheet that excel created
                        {
                            sql = "SELECT * FROM [" + sheet.Replace("'", "") + "]"; // command for the dataSet
                            DBCommand.CommandText = sql; // adding and executing the command
                            DBAdapter.Fill(DataSet); // adds or refreshes rows in the dataSet
                        }
                    }

                    connection.Close();
                    GC.Collect();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("cannot read file");
                }
            }

        }

        public void Writerows()
        {
            string[] headers1 = new string[DataSet.Tables[0].Rows.Count];

            int rowtotal = DataSet.Tables[0].Rows.Count;

        }


        public void WriteFiles()
        {

            string[] headers = new string[DataSet.Tables[0].Columns.Count];

            List<string> primes = new List<string>();
            int rowtotal = DataSet.Tables[0].Rows.Count;
            for (int i = 0; i < rowtotal; i++)
            {

               string name = DataSet.Tables[0].Rows[i].ToString();
                Excel.Application ExcelApp;
                Excel.Workbook WorkBook;
                Excel.Worksheet oSheet;

                string filename = ".csv";
                int lastUsedRow = 0;
                bool newFile = false;
                ExcelApp = new Excel.Application();
                ExcelApp.Visible = true;
                int columntotal = DataSet.Tables[0].Columns.Count;

                //Excel.Range firstFind = null;
                //Excel.Range currentFind = null;


                //  try
                //       {
                //    for (int w = 0; w < columntotal; w++)
                //      {

                //      string className ="Student ID";
                //        foreach (string x in DataSet.Tables[0].Rows[0].ToString())
                //        if (DataSet.Tables[0].Rows[0][w].ToString()==className)
                //        {
                //           name = DataSet.Tables[0].Rows[0][i].ToString();

                //        }

                //        else
                //        {
                //            name = DataSet.Tables[0].Rows[i][0].ToString();
                //        }
                //    }
                //}

                //catch
                //{

                //}

                for (int k = 0; k < columntotal; k++)
                {
                    headers[k] = DataSet.Tables[0].Columns[k].ColumnName.ToString();
                }

                if (!File.Exists(FullFolderPath + "/" + name + filename))
                {
                    WorkBook = (ExcelApp.Workbooks.Add(""));
                    oSheet = (Excel.Worksheet)WorkBook.ActiveSheet;
                    newFile = true;
                    //for (int q = 1; q < WorkBook.Sheets.Count; q++)
                    //{
                    //    //string sheetname = 
                    //    oSheet = (Excel.Worksheet)WorkBook.Sheets[q];
                    //    Console.WriteLine("Workbook");
                    //    newFile = true;

                    //}
                }

                // Otherwise open it
                else
                {
                    WorkBook = ExcelApp.Workbooks.Open(FullFolderPath + "/" + name + filename);
                    oSheet = (Excel.Worksheet)WorkBook.ActiveSheet;
                    Excel.Range last = oSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                    Excel.Range range = oSheet.get_Range("A1", last);
                    lastUsedRow = last.Row;
                    //oSheet.Cells[0] = toplabel
                }
                //for (int j = 0; j < columntotal; j++)
                //{

                //    oSheet.Cells[1, j + 1] = DataSet.Tables[0].Columns[headers[j]].ToString();
                //}
                for (int j = 0; j < columntotal; j++)
                {
                    int oo = 2;
                    if (newFile == false)
                    {
                        oSheet.Cells[lastUsedRow + 1, j + 1] = DataSet.Tables[0].Rows[i][headers[j]].ToString();
                    }
                    else
                    {
                        //using (conn)
                        //{
                        //    List<string> sheetnames = new List<string>();
                        //    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        //    if (dbSchema == null || dbSchema.Rows.Count < 1)
                        //    {
                        //        throw new Exception("Error: Could not determine the name of the first worksheet.");
                        //    }
                        //    for (int t = 0; i < dbSchema.Rows.Count; t++)
                        //    {
                        //        sheetnames.Add(dbSchema.Rows[i]["Table_Name"].ToString());




                                //String[] excelSheets = new String[oSheet.Worksheets.Count];
                                //int h = 0;
                                //foreach (Microsoft.Office.Interop.Excel.Worksheet wSheet in excelBook.Worksheets)
                                //{
                                //    excelSheets[i] = wSheet.Name;
                                //    h++;
                                //}

                               // oSheet.Cells[1, j + 1] = sheetnames;
                                oSheet.Cells[2, j + 1] = DataSet.Tables[0].Columns[headers[j]].ToString();
                                oSheet.Cells[oo + 1, j + 1] = DataSet.Tables[0].Rows[i][headers[j]].ToString();
                            //}
                      //  }
                    }
                    }

                    ExcelApp.UserControl = false;
                    DataSet ds = new DataSet();
                    // Two options for saving
                    if (newFile)
                    {

                        WorkBook.SaveAs(FullFolderPath + "/" + name + filename, Excel.XlFileFormat.xlCSV, Type.Missing, Type.Missing,
                        false, false, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    }

                    else
                    {
                        WorkBook.Save();
                    }
                    // WorkBook.Save();


                    WorkBook.Close(false);
                    ExcelApp.Quit();

                }
                MessageBox.Show("Done");
            
        }

    }
}
