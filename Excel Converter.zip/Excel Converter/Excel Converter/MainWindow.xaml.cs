﻿using System;
using Microsoft.Win32;
using System.Data.OleDb;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using Path = System.IO.Path;

namespace Excel_Converter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string FilePath = "";
        public string FullFolderPath = "";
        public string sheetzname = "";
        public DataSet DataSet { get; private set; }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            btnBrowse.IsEnabled = false;
            OpenFileDialog fd = new OpenFileDialog();

            fd.Title = "Select your ExceL File:";
            fd.Filter = "Excel Worksheets (.xls, .xlsx, .lsm, .csv)| *.xls; *.xlsm; *.xlsx; *.csv;";
            fd.DefaultExt = ".xls";


            Nullable<bool> result = fd.ShowDialog();

            if (result == true)
            {
                FilePath = fd.FileName;
            }
            btnBrowse.IsEnabled = true;
        }

        private void btnBrowseDestination_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog fd = new System.Windows.Forms.FolderBrowserDialog();

            // Sets starting directory of browse to 3 levels up from current directory
            fd.SelectedPath = System.IO.Path.GetFullPath(System.IO.Path.Combine(Directory.GetCurrentDirectory(), @"..\..\..\"));

            System.Windows.Forms.DialogResult result = fd.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                FullFolderPath = fd.SelectedPath;
            }
        }

        private void Run(object sender, RoutedEventArgs e)
        {
            if (IsReady())
            {
                ExcelReader excelReader = new ExcelReader(FilePath);
                excelReader.ReadFile();
                var sheets =excelReader.GetSheetNames();
                sheets = new List<string>();
                ExcelWriter excelWriter = new ExcelWriter(excelReader.GetDataset(), FullFolderPath);
                excelWriter.WriteXLSFiles();

            }
        }

        private bool IsReady()
        {
            if (FilePath == "")
            {
                MessageBox.Show("Please select a file");
                return false;
            }

            if (FullFolderPath == "")
            {
                MessageBox.Show("Please select a destination folder");
                return false;
            }

            return true;
        }
    }
}
