﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel =Microsoft.Office.Interop.Excel;
using Path = System.IO.Path;

namespace Excel_Converter
{
    public class ExcelReader
    {
        private OleDbConnection conn;
        private string provider;
        private string filePath = "";
        private DataSet dataSet { get; set; }

        public ExcelReader(string fp)
        {
            filePath = fp;

            dataSet = new DataSet();
        }

        public void ReadFile()
        {
            try
            {
                if (IsCSVFile())
                {
                    ReadCSVFile();
                }
                else
                {
                    ReadExcelFile();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to read file");
            }
        }

        public DataSet GetDataset()
        {
            return dataSet;
        }

        private bool IsCSVFile()
        {
            return Path.GetExtension(filePath).Equals(".csv");
        }

        private void ReadCSVFile()
        {
            StreamReader sr = new StreamReader(filePath);
            char[] delimChar = { ',', '\t' };

            // Parsing headers from the first line
            string[] headers = sr.ReadLine().Split(delimChar);

            DataTable dt = new DataTable();
            foreach (string header in headers)
            {
                dt.Columns.Add(header);
            }

            while (!sr.EndOfStream)
            {
                string[] row = Regex.Split(sr.ReadLine(), ",");
                //Other split char, = (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)
                DataRow dr = dt.NewRow();
                for (int i = 0; i < headers.Length; i++)
                {
                    // if this line is giving an IndexOutOfRange Exception, open the CSV file with Notepad, and check that the columns are still comma-separated
                    row[i] = row[i].Replace("\"", "");

                    dr[i] = row[i];
                }

                dt.Rows.Add(dr);
            }
            dataSet.Tables.Add(dt);
        }

        private void ReadExcelFile()
        {
            if (filePath != "")
            {
                String excelStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + @"; Extended Properties=""Excel 12.0; HDR=Yes; IMEX=2;"""; // File path and settings

                OleDbConnection connection = new OleDbConnection(excelStr);

                OleDbCommand DBCommand = new OleDbCommand();
                OleDbDataAdapter DBAdapter = new OleDbDataAdapter(DBCommand);

                DataTable dataTable;
                List<String> listSheet = new List<String>();
                DataRow dataRow;
                String sql;

                try
                {
                    DBCommand.Connection = connection;
                    DBCommand.CommandType = CommandType.Text;

                    connection.Open();

                    dataTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    // Creates a list of the tables names from the DataRow
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        dataRow = dataTable.Rows[i];
                        listSheet.Add(dataRow["TABLE_NAME"].ToString());
                        Console.WriteLine(dataRow["TABLE_NAME"].ToString());
                    }


                    // Fills up the DataSet from the created list
                    for (int i = 0; i < listSheet.Count; i++)
                    {
                        string sheet = listSheet[i];

                        if (!sheet.Contains("FilterDatabase")) // Checks to make sure that the sheet isn't a hidden repeat sheet that excel created
                        {
                            sql = "SELECT * FROM [" + sheet.Replace("'", "") + "]"; // command for the dataSet
                            DBCommand.CommandText = sql; // adding and executing the command
                            DBAdapter.Fill(dataSet); // adds or refreshes rows in the dataSet
                        }
                    }


                    connection.Close();
                    GC.Collect();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("cannot read file");
                }

            }
        }

        private bool PrepareExcelConnnection()
        {
            String excelStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + @"; Extended Properties=""Excel 12.0; HDR=Yes; IMEX=2;"""; // File path and settings
            var prvdr = excelStr;
            try
            {
                conn = new OleDbConnection(prvdr);
                conn.Open();
            }
            catch
            {

            }
            provider = prvdr;
            return true;
        }

        public List<string> GetSheetNames()
        {
            if (PrepareExcelConnnection())
            {
                using (conn)
                {
                    List<string> sheetnames = new List<string>();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determine the name of the first worksheet.");
                    }
                    for (int i = 0; i < dbSchema.Rows.Count; i++)
                    {
                        sheetnames.Add(dbSchema.Rows[i]["TABLE_NAME"].ToString());
                    }
                    return sheetnames;
                }
            }
            throw new Exception("Unable to open file");
        }

    }
}
