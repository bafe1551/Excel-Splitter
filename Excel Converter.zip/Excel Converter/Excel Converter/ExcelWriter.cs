﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Office.Interop;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms;

namespace Excel_Converter
{
    public class ExcelWriter
    {
        private DataSet dataSet;
        private string destinationFolder;
        public string sheetzname;

        public ExcelWriter(DataSet ds, string df)
        {
            dataSet = ds;
            destinationFolder = df;
      
        }

        public void WriteXLSFiles()
        {
            for (int sheet = 0; sheet < dataSet.Tables.Count; sheet++)
            {
                
            int rowtotal = dataSet.Tables[sheet].Rows.Count;
         
                for (int row = 0; row < rowtotal; row++)
            {
                    List<string> primes = new List<string>();
                    System.Data.DataTable currentSheet = dataSet.Tables[sheet];

                    string[] headers = new string[dataSet.Tables[sheet].Columns.Count];
                   
                    string name = currentSheet.Rows[row]["Student ID"].ToString();
                    string sheetname = currentSheet.TableName;
                    Microsoft.Office.Interop.Excel.Application ExcelApp;
                    Workbook WorkBook;
                    Worksheet oSheet;

                    string filename = ".csv";
                    int lastUsedRow = 0;
                    bool newFile = false;
                    ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                    ExcelApp.Visible = true;
                    int columntotal = currentSheet.Columns.Count;

                    string strworksheetname = dataSet.Tables[sheet].Namespace;

                    for (int k = 0; k < columntotal; k++)
                    {
                        headers[k] = currentSheet.Columns[k].ColumnName.ToString();
                    }

                    if (!File.Exists(destinationFolder + "/" + name + filename))
                    {
                        WorkBook = (ExcelApp.Workbooks.Add(""));
                        oSheet = (Microsoft.Office.Interop.Excel.Worksheet)WorkBook.ActiveSheet;
                        newFile = true;
                    }

                    // Otherwise open it
                    else
                    {
                        WorkBook = ExcelApp.Workbooks.Open(destinationFolder + "/" + name + filename);
                        oSheet = (Microsoft.Office.Interop.Excel.Worksheet)WorkBook.ActiveSheet;
                        Microsoft.Office.Interop.Excel.Range last = oSheet.Cells.SpecialCells(Microsoft.Office.Interop.Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                        Microsoft.Office.Interop.Excel.Range range = oSheet.get_Range("A1", last);
                        lastUsedRow = last.Row;
                        //oSheet.Cells[0] = toplabel
                    }
                    
                    for (int col = 0; col < columntotal; col++)
                    {
                        int oo = 2;
                        if (newFile == false)
                        {
                            oSheet.Cells[lastUsedRow + 1, col + 1] = currentSheet.Rows[row][headers[col]].ToString();
                        }
                        else
                        {
                            foreach (Worksheet worksheet in WorkBook.Worksheets)
                            {
                               // MessageBox.Show(worksheet.Name);

                                oSheet.Cells[1] = worksheet.Name;
                            }
                            oSheet.Cells[2, col + 1] = currentSheet.Columns[headers[col]].ToString();
                            oSheet.Cells[oo + 1, col + 1] = currentSheet.Rows[row][headers[col]].ToString();
                        }
                    }

                    ExcelApp.UserControl = false;
              
                    // Two options for saving
                    if (newFile)
                    {
                        Console.WriteLine(destinationFolder + "/" + name + filename);
                        WorkBook.SaveAs(destinationFolder + "/" + name + filename, Microsoft.Office.Interop.Excel.XlFileFormat.xlCSV, Type.Missing, Type.Missing,
                        false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    }

                    else
                    {
                        WorkBook.Save();
                    }
                    WorkBook.Save();

                    WorkBook.Close(false);
                    ExcelApp.Quit();
                }
            }

            MessageBox.Show("Done");
        }
    }
}
